#ifndef VIDEOHUB_PLUGIN_H
#define VIDEOHUB_PLUGIN_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Plugin ABI contract. The host calls every entry point on the main thread.
 * All strings are UTF-8 and remain valid only until the function returns.
 * reply must be called exactly once for each request.
 */
typedef void (*videohub_plugin_reply)(void *context, const char *result_json, const char *error_json);

/* Returns a process-lifetime instance, or NULL when initialization fails. No network I/O. */
void *videohub_plugin_create_v1(void);
/* Synchronous link recognition only. Returns 1 when the plugin accepts the link. */
int32_t videohub_plugin_can_handle_v1(void *instance, const char *link);
/* Returns a WKWebsiteDataStore pointer without transferring ownership. NULL without authentication. */
void *videohub_plugin_data_store_v1(void *instance);
/* Copies its inputs, performs the request asynchronously, then calls reply once. */
void videohub_plugin_request_v1(void *instance, const char *operation,
    const char *payload_json, void *context, videohub_plugin_reply reply);

/* API v2 uses the same argument layout and ownership rules. */
void *videohub_plugin_create_v2(void);
int32_t videohub_plugin_can_handle_v2(void *instance, const char *link);
void *videohub_plugin_data_store_v2(void *instance);
void videohub_plugin_request_v2(void *instance, const char *operation,
    const char *payload_json, void *context, videohub_plugin_reply reply);

#ifdef __cplusplus
}
#endif

#endif
