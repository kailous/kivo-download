# VideoHub Plugin API v1

本接口用于独立本地视频源插件。目标是新增平台只交付插件包，影视库、播放 UI 与 libmpv 后端继续使用统一数据，不针对平台新增分支。

- 开发 Agent 入口：[Plugins/AGENTS.md](../plugin-authoring.md)
- 可编译 SDK：[PluginContract.swift](../../VideoHubPluginSDK/Sources/VideoHubPluginSDK/PluginContract.swift)
- 已实现插件：BilibiliSource（宿主仓库示例）
- 机器可读描述：[schemas](schemas)
- 仅供测试的标准样例：[examples](examples)

SDK 与宿主运行校验是执行契约，JSON Schema 描述字段形状；跨字段约束（ID 唯一、过期时间、DASH 音频、媒体信息等）由 SDK 校验。示例域名为 example.invalid，不是产品作品或可播放资源。

## 运行模型与版本

插件是动态库包，当前构建面向 macOS 14+ / Apple Silicon，随应用提供的是本机构建的 arm64 包。包放到设置中安装，宿主验证清单、接口版本、路径和二进制 SHA-256，再加载四个 `_v1` C 符号。SHA-256 只防损坏，不构成发布者签名或隔离。插件拥有进程权限，当前不支持运行不受信任的代码。

成功加载的模块在本次进程内保持有效，避免异步回调指向卸载代码。停用和卸载立即移出视频源注册表并停止对应播放；卸载删除插件包而不删影视库、进度或 WebKit 账号数据。替换不同二进制需重启。插件安装目录是 `~/Library/Application Support/VideoHub/Plugins`；启用状态保存在该目录的 state.json。

`apiVersion: 1` 是兼容性边界。可新增可选字段，不改已有字段含义或类型。破坏性变更升级 API 与 C 符号后缀，宿主拒绝不支持的版本。清单必须声明 collection/playback；只声明实际实现的 authentication/danmaku 可选能力，未知能力在当前版本会拒绝安装。

## C ABI

```c
typedef void (*Reply)(void *context, const char *result_json, const char *error_json);
void *videohub_plugin_create_v1(void);
int32_t videohub_plugin_can_handle_v1(void *instance, const char *url);
void *videohub_plugin_data_store_v1(void *instance);
void videohub_plugin_request_v1(void *instance, const char *operation,
    const char *payload_json, void *context, Reply reply);
```

同步入口在主线程调用；请求入口立即复制 UTF-8 输入，后台完成后恰好回调一次。成功 result 非空/error 为空；失败反之。输出指针在 callback 返回前有效，宿主同步复制。instance 与 WKWebsiteDataStore 必须在模块本次生命周期内保持有效，data_store 返回未转移所有权的 WebKit 对象；无认证插件仍导出此符号但返回 null。

取消操作会让宿主忽略返回结果，不保证底层网络立即中断；插件仍应正确回调，且设置网络超时。不跨 ABI 传递 Swift Codable 对象或自定义类。JSON 与错误都不得直接打印日志。

## 操作与输入输出

| operation | 请求 payload | 结果 |
| --- | --- | --- |
| collection | URL 的 JSON 字符串，例如 `"https://example.invalid/watch/1"` | PluginCollectionDTO |
| playback | `{ "episode": PluginEpisodeDTO, "quality": 80 }` | PluginPlaybackDTO |
| danmaku | `{ "episode": PluginEpisodeDTO, "segment": 1 }` | PluginDanmakuDTO 数组 |
| account | `null` | `{ "authenticated": false }` 或带 displayName 的已登录状态 |
| logout | `null` | `null`，完成本平台退出后才返回 |

未知 operation 应返回 UNSUPPORTED_OPERATION。未声明的可选能力宿主不调用，不要用空数组或假账号伪造成功。

## 稳定标识与目录

作品和剧集 id 都是稳定字符串；宿主用 `(pluginID, kind, externalID)` 建立 SQLite 映射。不同插件相同原始 ID 不会共享进度。映射与影视库一起备份。旧 Bilibili 库的正整数 ID 有显式迁移兼容规则，其他源使用独立的本地标识，不应依赖宿主内部数字。

分区 id 在作品内唯一；同分区剧集 id 不重复，平台顺序就是播放顺序。不同分区可以引用同一剧集。`duration` 统一为秒，未知可为 0，不用毫秒。`cover`、`backdrop`、`canonicalURL` 可省略；作品与剧集标题不能省略。

`sourceData` 是插件不透明的稳定标识字典，宿主原样传回，用于 aid/cid、版本或资源键等。不存凭证、Cookie、令牌、短期 URL 或整份 API 响应。播放器和 UI 不解释 sourceData，不认识平台内部 JSON。

## 内容分类（兼容性可选字段）

`PluginCollectionDTO.contentType` 可为 movie、series、animation、variety、documentary 或 unknown。平台适配器根据真实频道类型映射；无可靠字段返回 unknown 或省略。不用片名和集数猜测。宿主保留独立手动覆盖值，刷新目录不会改掉手动选择；旧插件无需升级 ABI。

## 直播标记（兼容性可选字段）

`PluginEpisodeDTO.isLive` 为 true 表示持续播出的直播流。宿主据此跳过续播进度（不写入、不出现在继续观看），关闭播完自动连播，并允许播放器用上/下方向键切换同一目录内的相邻直播条目：跨分区按目录顺序前进、跳过非直播和不可播放项、首尾不循环。直播播放时上/下不再调节音量或唤出控制栏，Tab 聚焦播放控制。只对真实直播流设置 true，点播、回看和付费单片保持省略或 false。旧插件省略该字段按点播处理，无需升级 ABI。

## 播放输出

- `video`：当前有权访问的主媒体 URL；HLS 是播放列表，HTTP 可为直连单文件。
- `audio`：分离 DASH 的音频 URL；MPD 自带音频时可为空，单轨 DASH 必须提供音频。
- `format`：DASH、HLS 或 HTTP；`duration` 为秒。
- `qualities`：实际可用的整数质量 ID 和展示标签；`qualityID` 必须在列表中。不伪造用户无权访问的清晰度。
- `preview`：当前是否仅获得试看。当前宿主会明确提示试看权限，不把试看当完整正片。
- `headers`：本次播放需要的 HTTP 请求头，最多 32 项，不允许换行/NUL，值不超过 8192 UTF-8 字节。每次加载清空旧源请求头，再设置当前资源头部。媒体请求与元数据/登录请求头不能混用。
- `expiresAt`：可选 Unix 秒，明确过期的地址被拒绝并提示重试。当前仍以手动重试重新解析，尚无自动到期刷新承诺。

清晰度切换再次调用 playback。初次请求的 quality 可能是宿主默认值 80；插件不认识该值时选择实际可用的默认质量，并在 qualityID 中返回选中项。媒体地址、请求头和广告策略不写入影视库、备份或复制入口。认证、目录和媒体只走平台允许接口，不尝试移除 DRM、解锁付费或改变地区权限。

现有音轨/字幕选择来自原生引擎识别的容器/清单轨道。API v1 尚不接受单独外部字幕清单、多组外部音频或插件自定义播放后端。需要这些能力时按版本扩展；不要改播放器去识别平台字段。

## 广告：播放优先的可选扩展

`adPolicy` 可省略，默认未知，不阻断已有合法媒体播放；无法识别或时间段异常的广告元数据按未知处理，原始媒体流不被删改；不能因为广告信息缺失就假定用户有免广告权限，也不自动过滤媒体流中的广告。

```json
{
  "mode": "embedded",
  "canSkip": false,
  "breaks": [{ "id": "pre-1", "start": 0, "end": 15, "canSkip": false }]
}
```

- mode 支持 unknown / none / embedded / clientSide；breaks 使用整段媒体的秒数，按时间排序、不重叠。
- embedded 表示广告已经在平台返回的完整流中。已知不可跳过段限制 seek、续播起点和倍速；只有账号权限和该段都允许时才可跳过。
- Bilibili 当前未可靠获得统一广告政策，明确输出 unknown，沿用原平台授权媒体，不伪造“无广告”或免广告权益。
- clientSide 独立广告素材、SDK、曝光/完成上报与 VAST/VMAP 是第二版后续兼容项，目前没有实现。字段存在不等于流程已支持。不得制造广告完成回调或绕过平台必须完成的授权前置步骤。

## 错误与隐私

error_json 为 PluginFailureDTO：`code`、`message`、`retryable`。建议稳定使用 INVALID_REQUEST / AUTH_REQUIRED / ACCESS_DENIED / NOT_FOUND / NETWORK_ERROR / SOURCE_ERROR / UNSUPPORTED_OPERATION。宿主保留错误码，展示去除 URL 后的消息；当前 retryable 是语义提示，不代表已实现自动重试。

客户端不提供真实媒体 URL 的显示、复制或导出，原生播放器关闭终端输出。临时媒体只在插件调用和播放器内存中使用。纯本地程序不能保证抵抗进程检查、抓包或调试；隐藏 UI 不等于 DRM 或绝对防提取。不要向用户承诺“无法下载/分发”。

## 验证

先执行 `bash scripts/build-app.sh` 生成真实安装包，再用 README 的缓存环境运行 Swift tests。集成测试实际安装、动态加载、识别、通过 C 回调传回结构化错误、停用、重新启用、卸载和重启读取状态；没有网络时不伪造真实播放成功。原生音频测试验证独立音轨和媒体头部数组。实时登录、有声播放、平台广告流程及外部插件仍需实机验收。

内联 HLS 与不完整目录扩展参见 [API v2](../v2/README.md)，v1 Bilibili 包继续兼容。

弹幕 size 是字号倍率，1 表示默认字号；时间为整集秒数。episode.number 为展示用字符串，可以是数字、日期、期次或上下集标签；顺序以插件 sections/episodes 数组为准。

## 正片目录扩展（宿主0.4.2，可选字段，ABI兼容）

- `PluginSectionDTO.role` / `PluginEpisodeDTO.role`：main、trailer、extra、alternate、unknown。剧集值优先，否则继承所在分区；均缺失则 unknown。未来未知字符串也解码为 unknown，不默认正片。
- role 是编辑内容角色，与VIP、购买等播放权益分离；VIP正片仍为main。平台没有明确信息时保留unknown，不能让宿主按平台ID或片名猜测。
- 同一作品内正片按平台分区与剧集顺序展开、按稳定剧集ID去重。`section.playbackGroupID` 相同且非空明确表示可跨分区连续播放（例如同一专辑的年份段）。缺失时不跨分区自动连播，不能用它拼接不同季。
- `episode.availability`：released、unreleased、unavailable、unknown；是发布/可用状态，不代表用户有会员权益。缺失/unknown仍可请求真实播放授权，unreleased/unavailable不会成为自动下一集。
- 旧插件、旧数据库的可选值仍可解码；保留原有单集播放和进度，未分类内容不进入正片自动连播链。旧宿主忽略新增可选字段，无需更换C符号。
- 完整目录仍输出全部内容，不能为了让选集只显示正片而删掉花絮、其他版本或未知条目。宿主在详情页独立展示附加内容。

## 内容分级与自动目录

新插件包必须在清单顶层声明 `contentRating`。只提供普通内容时填 `"general"`。只要能提供不宜儿童观看的内容，即使混在普通目录里或通过分类切换提供，也要填 `"adult"`。分级适用于整个插件。SDK 模板会在编译前校验，宿主安装会拒绝缺少分级的包。宿主启动时兼容此前已安装且未声明分级的普通插件。重新安装需补齐。[儿童锁插件清单样例](examples/manifest-child-lock.json)

受儿童锁限制的插件仅面向支持儿童锁的宿主。儿童锁每次启动默认锁定，设置和侧栏隐藏受限插件，影视库隐藏不宜儿童观看的内容。重新锁定会停止对应播放、停用源并丢弃在途插件结果。解锁按原有启用开关恢复插件。

如需提供免手工添加的目录，在清单的 `sidebar` 中声明 `catalogURL`（HTTPS）。宿主打开侧栏时向插件发送原有 `collection` 请求，并附加从 1 起的 `page` 参数。选中类型时附加 `category` 参数，值为插件返回的类型 ID。对应插件实现 `catalogFilters` 操作（输入 `null`，输出 `[{ "id": "category-id", "title": "类型名" }]`）。目录与类型只在当前浏览会话使用，条目继续通过现有 `playback` 操作播放。

声明 `sidebar.catalogSearch: true` 后，宿主将整站搜索关键词作为 `search` 查询参数与 `category`、`page` 一起传给 `collection`。插件返回当前搜索结果页，修改关键词时宿主回到第一页。

`sidebar.recommendationsURL` 可为自动目录声明推荐页的 HTTPS 地址。宿主用同一个 `collection` 操作获取推荐视频，并按返回顺序在首屏轮播最多 10 条。收藏保存在 Kivo 的本地影视库备份中，以插件与剧集标识区分，不需要平台账号。

自动目录可以用 `sidebar.catalogActions` 声明目录操作（`favorite`、`filter`、`refresh`）。宿主依据声明渲染顶部工具栏，遥控器菜单键在目录右侧打开对应的上下文操作。省略时沿用自动目录原有操作。
