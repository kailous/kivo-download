# Plugin API v2：内联 HLS

v2 保留 v1 的目录、账号、错误、广告策略和 C ABI 参数布局，新增可选 `PluginPlaybackDTO.inlineHLS`。适用于平台直接返回播放列表文本、而非可再次请求的 m3u8 URL 的场景。它是平台无关的播放输入能力，不是爱奇艺专用播放器。

## 版本协商

- 包清单设置 `apiVersion: 2`。
- 导出 create / can_handle / data_store / request 四个 `videohub_plugin_*_v2` 符号，参数和所有权规则同 v1。
- 新宿主同时支持 v1 与 v2。旧宿主会拒绝 apiVersion 2，避免忽略内联列表后加载错误的资源。
- Bilibili 继续使用 v1，不需要迁移。只使用直连 URL 的插件也可继续交付 v1。

## 输出

除原有播放字段外，增加：

```json
{
  "video": "https://example.invalid/first-segment.ts",
  "audio": null,
  "format": "HLS",
  "duration": 120,
  "qualityID": 500,
  "qualities": [{"id":500,"label":"720p"}],
  "preview": false,
  "headers": {},
  "inlineHLS": "#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:4,\nhttps://example.invalid/first-segment.ts\n#EXT-X-ENDLIST\n"
}
```

这是只用于字段示例的无效域名。内联模式下 video 为平台真实返回的首个媒体分段地址，用于维持资源标识及格式校验；宿主实际加载完整 inlineHLS，而不是只播放这个分段。

列表必须以 #EXTM3U 开头、不超过 2 MiB、无 NUL；普通 URI 行以及 URI="..." 标签引用必须是完整 HTTP(S) 地址。插件必须先把可明确解析的相对引用规范化，不能猜测签名 URL，也不能过滤、重排广告或媒体片段。

宿主通过 libmpv memory:// 输入加载文本，并使用 FFmpeg HLS demuxer。文本不写到磁盘、不建立本地 HTTP 代理、不提供下载/复制入口。媒体请求头仍从 headers 设置，后续加载非 HLS 输入时会清除强制格式，避免影响其他视频源。

DRM 及专用授权 SDK 不因增加内联列表而得到支持。插件必须识别并报告无法适配的保护类型，不能把解密或权限绕过当成格式兼容。广告规则沿用 v1：未知策略不阻断现有合法播放，不主动过滤广告或伪造完成。

## 验证

- `bash scripts/test-inline-hls.sh`：真实 libmpv 在内存加载测试 HLS，验证视频与 48kHz 音频解码，不使用代理。
- 原有 v1 插件回归测试必须继续通过。
- 爱奇艺真实链接验证是单独的 opt-in 网络测试，默认不会自动联网。具体执行和结果见插件 README。

## 不完整目录

`PluginCollectionDTO.isComplete` 可选。false 表示只返回已读取到的部分目录；宿主合并已知剧集，不能用这一页覆盖并删除先前读取的剧集。true 或缺失沿用完整目录替换语义。插件必须如实标记，不能把当前一集冒充全集目录。规范播放页使用 episode.canonicalURL，不能强行从平台数字 ID 拼出不适用的网页 slug。

正片角色、availability、playbackGroupID 可选扩展与 v1 共用，参见 [v1 正片目录扩展](../v1/README.md)。不影响 inlineHLS 或已授权媒体，旧字段含义不变。

内容分级和自动目录沿用 [v1 清单及操作定义](../v1/README.md#内容分级与自动目录)。
