# VideoHub 视频源插件开发 Agent 指南

适用于本目录中的视频源插件，以及使用本项目 SDK 开发的新插件。先阅读 `docs/plugins/v1/README.md` 和 `docs/plugins/v2/README.md`，以 `Sources/VideoHubPluginSDK/PluginContract.swift` 为实际运行契约。本文不能替代平台授权和接口许可。

## 目标与边界

- 新增平台应交付可安装的 `.bundle` 包，通过统一输出驱动现有影视库、播放器和弹幕 UI。
- 不修改 `PlayerScreen`、影视库页面或 libmpv 桥接来适配平台；平台差异留在插件内。
- SDK v1/v2 使用进程内 C ABI 与 UTF-8 JSON；不能向宿主返回自定义 Swift 类、WebView 播放器或平台网页 UI。
- 不使用外部 mpv 进程、视频代理或默认永久下载。只访问用户账号和平台允许的资源，不绕过 DRM、付费、地区或访问控制。
- 播放优先：广告元数据暂缺时保持原平台已授权媒体的正常播放，不以缺少广告扩展一律拒播。不主动删除广告、制造跳过权限或伪造广告完成回调。

## 开始前

1. 检查平台实际可用接口、登录方式和权限，先验证一条真实目录 → 剧集 → 原生播放链路。
2. 声明 `collection`、`playback` 必需能力，以及实际实现的 `authentication`、`danmaku` 可选能力。没有实现的能力不要声明。
3. 使用唯一、稳定、全小写的插件 ID。内容 ID 用平台原始稳定字符串，不用临时播放 URL、标题或列表下标。
4. 阅读已有 `Plugins/BilibiliSource` 的运行实现与 `Tests/BilibiliSourceTests`；不要把 Bilibili 的字段复制到公共输出。

## 推荐结构

```
YourSource/
  Sources/
    PluginEntry.swift          # 四个 C ABI 导出
    Authentication/           # 本平台登录及 Cookie 会话
    URLParser/
    CollectionParser/
    PlaybackResolver/
    Danmaku/                  # 可选
  Tests/
  README.md
```

依赖公开的 `VideoHubPluginSDK` SwiftPM 产品。不要依赖宿主可执行目标的内部类型。包内模型可以不同，通过 DTO 映射输出。

## 必须导出的接口

从 SDK 导入 `PluginReply` 等 C 函数类型，导出以下符号，名称和参数顺序不能改变：

- `videohub_plugin_create_v1()`：返回持有的实例指针，失败返回 null。主线程同步调用，不能进行网络请求。
- `videohub_plugin_can_handle_v1(instance, link)`：同步返回 1/0，只做链接识别，不做网络 I/O。
- `videohub_plugin_data_store_v1(instance)`：返回插件持有的 `WKWebsiteDataStore` 未转移所有权指针。没有登录能力时返回 null；不要每次创建新会话。
- `videohub_plugin_request_v1(instance, operation, payload, context, reply)`：先复制输入字符串，再异步处理。每次调用恰好回调一次。

所有输入 JSON 与 C 字符串由宿主持有，只在函数返回前有效。后台任务不可保留这些指针。SDK C 回调函数与 context 地址需保存到回调完成，不要把裸指针直接跨 Swift 6 actor。参考 Bilibili 的 `PluginReplyBox` 和地址转换。

回调成功：`reply(context, resultJSON, nil)`；失败：`reply(context, nil, errorJSON)`。结果指针在回调返回后可释放，宿主会立即复制。不要两边都为空，不要成功和错误同时返回，不要重复回调。C 入口不抛 Swift 异常。宿主取消不会终止 C 函数，插件仍须完成一次回调；宿主会丢弃已取消任务的结果。网络请求应有超时。

## 输出要求

- `collection` 请求是一个 JSON URL 字符串，响应为 `PluginCollectionDTO`。完整输出分区顺序、剧集顺序、标题、时长、封面及规范链接。
- `playback` 请求为 `PluginPlaybackRequest`，响应为 `PluginPlaybackDTO`。视频和音频按平台实际提供返回，不伪造轨道或清晰度。
- `danmaku` 请求为 `PluginDanmakuRequest`，分段序号从 1 开始；响应为 `[PluginDanmakuDTO]`。时钟单位是整集秒数，不是段内毫秒数。
- `account` 返回 `PluginAccountDTO`，未登录返回 `authenticated: false`，不伪造成功；`logout` 清理本平台 WebKit 数据后返回 JSON null。
- `sourceData` 只放插件需要透传的稳定标识。不要放 Cookie、账号密码、访问令牌、短期签名媒体地址或完整平台响应。宿主不解释该字典。
- 弹幕 `size` 是字号倍率（1 为默认），不能直接填像素数；当前播放器统一处理用户字号、透明度和区域设置。
- 剧集 `number` 可为数字、日期、期次或上下集标签，不保证能转整数。不同内容类型应由插件选择目录规则，并输出正确分区和顺序，不能要求播放器解析片名判断综艺或电视剧。
- 统一使用秒数；过期时间为 Unix 秒。HLS 返回真实播放列表；分离 DASH 返回视频与音频；MPD 可包含自身音轨。DRM 资源明确失败，不返回绕过路径。
- 媒体请求头放在 `headers`，每次播放单独设置，不修改宿主全局 Referer。不得向不匹配的域名转发整份登录 Cookie。
- `expiresAt` 能确定时必须提供，不知道时省略。短期 URL 只走播放输出，不写目录、数据库、日志或示例文档。
- 错误返回 `PluginFailureDTO`：稳定错误码、给用户看的消息和是否可重试。不要在错误里暴露媒体 URL、Cookie 或请求头。
- 使用 `PluginContract.validate` 校验目录和播放输出。用仓库 examples 做编解码契约测试，扩展字段只能增加为可选字段，破坏性修改必须升级 API。

## 广告扩展（第二版验收）

`adPolicy` 是可选字段，缺失/unknown 不阻断现有合法播放。未拿到明确权益时，`canSkip` 不得设 true。不得用 VIP 身份猜测所有广告都能跳过。

完整流内广告用 `embedded`，未知或无效广告元数据按未知处理，不能影响合法媒体加载；时间段必须来自平台，`breaks` 按开始时间排序且不重叠。只有账号总权限和对应广告段都允许跳过时才允许跳过。当前宿主对已知不可跳过时间段限制 seek 与倍速；未知广告不做猜测跳过。

独立广告素材、广告 SDK、曝光/完成上报和 VAST/VMAP 尚未完成适配。声明 `clientSide` 只能描述事实，不代表宿主已具备流程支持。不得伪造完成上报或通过额外请求获取绕过平台前置权限的正片。将无法支持的流程与真实测试证据写进 README，优先保持平台已经授权的完整媒体正常播放。

## 包与安装

- 新交付插件包的 `Contents/manifest.json` 必须声明顶层 `contentRating`。只提供普通内容的源填 `general`。只要插件能提供不宜儿童观看的内容，即使混在普通目录里或通过分类切换提供，也要填 `adult`。分级以整个插件为单位，不能留空或只在单个条目上标注。
- 受儿童锁限制的插件仅支持带儿童锁的 Kivo。验收锁定时隐藏、拒绝安装与调用，解锁后按插件启用状态显示，重新锁定后停止播放。

```
<id>.bundle/
  Contents/
    Info.plist
    manifest.json
    MacOS/<executable>
```

清单字段参见 schema；直连资源使用 `apiVersion: 1`，内联 HLS 使用 `apiVersion: 2` 及对应 `_v2` 四个导出符号。必需能力 `collection` 与 `playback`。认证能力同时提供 HTTPS `loginURL`、数据存储和 account/logout；如播放必须登录，设置 `authenticationRequired: true`。弹幕能力必须提供 `danmakuSegmentDuration` 秒数。

按目标 macOS/CPU 编译独立动态库，签名后计算 SHA-256，再写入清单；不能先算摘要再改二进制。SHA-256 只检查完整性，不是发布者可信签名。当前插件在应用权限内运行，不是隔离沙箱，只安装可信代码。

示例命令：`bash scripts/package-bilibili-plugin.sh`。插件的第三方动态依赖必须打包并正确设置安装路径；不能把开发机绝对路径当作发行依赖。当前成功加载的代码保持在进程内，替换不同二进制前需重启应用，不能在异步回调进行时 dlclose。

## 验证与交付

1. 先编译 SDK 与插件，再运行插件自己的解析、权限、广告声明和 DTO 测试。v2 插件还需运行 `bash scripts/test-inline-hls.sh`。
2. `bash scripts/build-app.sh` 生成真实插件包与应用。
3. 使用文档中的缓存环境执行 `swift test --disable-sandbox --cache-path "$PWD/.build/cache"`，运行 `bash scripts/test-native-audio.sh`。
4. 实际验证安装 → 启用 → 登录 → 添加作品 → 有声播放 → 目录/清晰度/弹幕能力 → 停用 → 卸载 → 重启恢复。
5. 测试相同平台 ID 在不同插件下不冲突，旧库和备份可恢复；未授权、断网、过期和损坏包必须有真实错误。
6. 手动检查没有地址显示/复制入口，错误与日志不出现临时 URL。不要宣称本地内存中的资源绝对无法被检查。
7. 更新 README，列清平台限制与未验证项。测试样例明确标注 fixture，不能作为产品中的假作品。

不能只交付清单、静态 UI 或文档；插件代码必须真实存在，且统一输出能被未改造的宿主接收。发现需要改播放器或 UI 才能接入时，先检查是否可用现有 DTO 表达；确实需要新能力时提出独立版本扩展，不静默改坏 v1。

新增平台优先使用现有输出协议。v2 的 inlineHLS 是唯一新增输入扩展，规则见 v2 文档，不得用本地代理、落盘带签名列表或改播放器 UI 代替该能力。

## 0.4 内容分类

可选 `PluginCollectionDTO.contentType` 统一使用 movie / series / animation / variety / documentary / unknown；根据平台明确类型字段输出，不按标题或集数猜测。旧插件省略值显示未分类；宿主手动覆盖独立保存，刷新不能清掉。不要给播放器添加平台分类分支。

## 0.4.2 正片目录与数字选集

输出 section/episode 的可选 role（main / trailer / extra / alternate / unknown），由平台真实结构映射，剧集覆盖分区角色。VIP不等于alternate；不要因为付费标签删除正片。分区之间确属同一播放序列时输出共同的非空 playbackGroupID，不给不同季相同值。availability只表达发布/可用状态，不能推测会员授权。未知值或旧输出保持unknown，宿主不会猜平台分区ID。目录必须保留所有附加与未知内容，不能过滤后伪造“完整目录”。真实集号/期次/日期保留在number，不按数组索引改号；宿主负责紧凑展示。

## 0.4.3 直播标记

可选 `PluginEpisodeDTO.isLive` 为 true 表示持续播出的直播流。宿主据此跳过续播进度、关闭播完自动连播，并允许播放器用上/下方向键切换目录内相邻直播条目（跨分区、跳过非直播与不可播放项、首尾不循环）；直播时上/下不调节音量，Tab 聚焦播放控制。只对真实直播流标记，点播、回看和单片保持省略或 false；旧插件省略该字段按点播处理。不要给播放器添加平台或频道分支，直播行为只看该声明。
