# Kivo 插件 SDK 1.1.1

在 Kivo 内开发视频源插件的最小发行包。插件以进程内 C ABI + UTF-8 JSON 运行，只输出目录、播放资源、账号与弹幕数据；影视库、播放器和 libmpv 由宿主统一提供。

- 平台：macOS 14+，Swift 6
- 插件 API：v1，内联 HLS 为 v2
- 宿主版本：Kivo 0.5.0 及更新版本。受儿童锁限制的插件仅面向实现儿童锁与内容分级的宿主。
- 不包含：宿主源码、播放器、WebView UI、mpv、任何第三方平台实现

## 包内容

```
KivoPluginSDK-1.1.1/
  README.md                     本文件
  include/videohub_plugin.h     C ABI 声明
  VideoHubPluginSDK/            可被 SwiftPM 依赖的契约库
  Template/                     可编译、可打包的插件模板
  docs/plugins/v1/              接口规范、JSON Schema、示例
  docs/plugins/v2/              内联 HLS 扩展
```

`VideoHubPluginSDK` 包含公共 DTO、内容分级枚举、C 回调类型与 `PluginContract.validate`。打包时从 Kivo 当前接口源复制。

## 快速开始

```sh
cp -R Template MyPlugin
cd MyPlugin
# 编辑 plugin.json 的 id、name、version、summary 和 contentRating
# 编辑 Sources/PluginSource/TemplateSource.swift：识别链接、目录、播放
bash build.sh
```

产物为 `build/<id>.bundle`。在 Kivo 的插件设置中选择安装；安装后添加一个能被 `can_handle` 识别的链接。替换二进制前需要重启 Kivo。

`Template/Package.swift` 通过相对路径 `../VideoHubPluginSDK` 依赖 SDK，因此模板必须与 `VideoHubPluginSDK/` 放在同一目录下。复制到其他位置时同步复制或改写依赖路径。

## 必须实现的约定

插件动态库导出四个 C 符号，参数与所有权规则不能改变：

```c
void *videohub_plugin_create_v1(void);
int32_t videohub_plugin_can_handle_v1(void *instance, const char *link);
void *videohub_plugin_data_store_v1(void *instance);
void videohub_plugin_request_v1(void *instance, const char *operation,
    const char *payload_json, void *context, videohub_plugin_reply reply);
```

Swift 模板把这四个入口函数声明为 `public`。release 构建会内部化未导出的符号，导致动态库中看不到 C 符号；不要改成 `private` 或 `internal`。

- `create` 在主线程同步调用，不能发起网络请求；返回的实例在进程内保持有效。
- `can_handle` 只做链接识别，不联网，返回 1 或 0。
- `data_store` 返回未转移所有权的 `WKWebsiteDataStore`；没有登录能力时返回 `NULL`。
- `request` 先复制输入字符串，再异步处理，并且每次恰好回调一次。取消只让宿主丢弃结果，插件仍须回调。
- 成功：`reply(context, resultJSON, NULL)`；失败：`reply(context, NULL, errorJSON)`。错误必须是 `PluginFailureDTO`，不得包含媒体 URL、Cookie 或请求头。

`operation` 与请求/响应类型：

| operation | 请求 | 响应 |
| --- | --- | --- |
| `collection` | URL 的 JSON 字符串 | `PluginCollectionDTO` |
| `playback` | `PluginPlaybackRequest` | `PluginPlaybackDTO` |
| `danmaku` | `PluginDanmakuRequest` | `[PluginDanmakuDTO]` |
| `account` | `null` | `PluginAccountDTO` |
| `logout` | `null` | `null` |

只声明实际实现的能力。`collection` 与 `playback` 必需；`authentication`、`danmaku` 可选。v2 插件必须导出对应的 `_v2` 四个符号。

直播频道在剧集上设置 `isLive: true`：宿主跳过续播进度、关闭自动连播，并允许播放器用上/下键切换相邻直播条目。不要用 URL、标题或插件 ID 判断直播。

完整字段与跨字段约束见 `docs/plugins/v1/README.md`、`docs/plugins/v2/README.md` 与 `VideoHubPluginSDK/Sources/VideoHubPluginSDK/PluginContract.swift`。SDK 中的 `PluginContract.validate` 是执行契约，JSON Schema 只描述字段形状。

## 插件包结构

```
<id>.bundle/
  Contents/
    Info.plist
    manifest.json
    MacOS/<executable>
```

`manifest.json` 由 `Template/build.sh` 从 `plugin.json` 生成，并写入签名后二进制的 SHA-256。先改二进制再算摘要；不能先算摘要再修改文件。SHA-256 只用于完整性校验，不是发布者签名，宿主也不是隔离沙箱，只安装可信代码。

## 内容分级与儿童锁

新插件包必须在 `plugin.json` 和最终 `Contents/manifest.json` 的顶层声明 `contentRating`。模板会在编译前检查，Kivo 会在安装和加载插件代码前校验。

| 值 | 适用范围 |
| --- | --- |
| `"general"` | 仅提供普通内容的插件 |
| `"adult"` | 能提供不宜儿童观看的内容的插件，包括混合目录和可切换到此类内容的源 |

如果插件能提供不宜儿童观看的内容，请把模板默认值改为 `"contentRating": "adult"`。[儿童锁插件清单样例](docs/plugins/v1/examples/manifest-child-lock.json)

Kivo 每次启动都锁定儿童锁。锁定时，受儿童锁限制的插件会从可用插件列表、已安装插件列表和侧栏隐藏，且无法安装或启用。影视库也会隐藏不宜儿童观看的内容。解锁后恢复原有插件开关状态。重新锁定会停止对应播放、撤销源注册，并丢弃在途插件结果。分级由开发者如实声明，适用于整个插件。

已安装的旧普通插件可继续使用原清单。重新安装或分发时，请补上分级。SDK 1.1.1 仍使用原有 `apiVersion: 1/2` 及 C ABI 符号。

## 安全与隐私

- 不返回或打印媒体 URL、短期签名、Cookie、令牌和请求头。
- `sourceData` 只放插件自用的稳定标识，不得放凭证或整份平台响应。
- 只访问用户账号和平台允许的资源；不绕过 DRM、付费、地区或访问控制。
- 媒体请求头只放在播放输出的 `headers`，不修改宿主全局状态。
- 模板中的 `example.invalid` 只用于展示接口形状，不会联网。

## 版本策略

`apiVersion` 是兼容边界。可在既有 DTO 上新增可选字段；已有字段的名称、类型和含义不得改变。破坏性变更会提升 API 版本并更换 C 符号后缀，旧宿主会拒绝不支持的版本。

## 限制

- 当前构建面向本机 macOS / arm64，使用 ad-hoc 签名；跨架构分发需要自行编译并签名。
- 插件在宿主进程权限内运行，没有单独沙箱。
- 已加载的模块在同一进程内保持映射；替换不同二进制必须重启 Kivo。
- 停用与卸载不会删除影视库、进度或 WebKit 账号数据。
