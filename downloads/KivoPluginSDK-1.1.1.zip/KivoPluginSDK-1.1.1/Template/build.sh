#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

python3 - <<'PY'
import json, pathlib

metadata = json.loads(pathlib.Path("plugin.json").read_text())
if metadata.get("contentRating") not in ("general", "adult"):
    raise SystemExit('plugin.json 必须声明 "contentRating": "general" 或 "adult"。')
PY

swift build -c release --product PluginSource

id=$(python3 -c 'import json; print(json.load(open("plugin.json"))["id"])')
api_version=$(python3 -c 'import json; print(json.load(open("plugin.json"))["apiVersion"])')
executable=$(python3 -c 'import json; print(json.load(open("plugin.json"))["executable"])')
dylib=".build/release/libPluginSource.dylib"

for symbol in create can_handle data_store request; do
  if ! nm -gU "$dylib" | grep -q "_videohub_plugin_${symbol}_v${api_version}$"; then
    echo "缺少导出符号：videohub_plugin_${symbol}_v${api_version}" >&2
    exit 1
  fi
done

mkdir -p build
stage="$(mktemp -d "$PWD/build/.stage.XXXXXX")"
trap 'rm -rf "$stage"' EXIT
bundle="$stage/$id.bundle"
mkdir -p "$bundle/Contents/MacOS"
cp "$dylib" "$bundle/Contents/MacOS/$executable"

python3 - "$bundle" "$PWD/plugin.json" <<'PY'
import json, pathlib, plistlib, sys
bundle = pathlib.Path(sys.argv[1])
meta = json.loads(pathlib.Path(sys.argv[2]).read_text())
(bundle / "Contents/Info.plist").write_bytes(plistlib.dumps({
    "CFBundleIdentifier": "local.kivo.plugin." + meta["id"],
    "CFBundleExecutable": meta["executable"],
    "CFBundlePackageType": "BNDL",
    "CFBundleVersion": "1",
    "CFBundleShortVersionString": meta["version"],
}))
PY

codesign --force --sign "${CODE_SIGN_IDENTITY:--}" "$bundle/Contents/MacOS/$executable"

python3 - "$bundle" "$PWD/plugin.json" <<'PY'
import hashlib, json, pathlib, sys
bundle = pathlib.Path(sys.argv[1])
meta = json.loads(pathlib.Path(sys.argv[2]).read_text())
binary = bundle / "Contents/MacOS" / meta["executable"]
meta["sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest()
(bundle / "Contents/manifest.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2))
PY

target="build/$id.bundle"
rm -rf "$target"
mv "$bundle" "$target"
echo "$PWD/$target"
