// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "PluginSource",
    platforms: [.macOS(.v14)],
    products: [
        .library(name: "PluginSource", type: .dynamic, targets: ["PluginSource"])
    ],
    dependencies: [
        .package(path: "../VideoHubPluginSDK")
    ],
    targets: [
        .target(
            name: "PluginSource",
            dependencies: [.product(name: "VideoHubPluginSDK", package: "VideoHubPluginSDK")]
        )
    ]
)
