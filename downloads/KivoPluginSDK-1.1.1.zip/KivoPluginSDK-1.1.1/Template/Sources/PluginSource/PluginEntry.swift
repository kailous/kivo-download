import VideoHubPluginSDK
import Foundation

private struct ReplyBox: @unchecked Sendable { let callback: PluginReply }

private struct PluginError: LocalizedError {
    let code: String
    let message: String
    let retryable: Bool
    var errorDescription: String? { message }
}

@MainActor private final class PluginRuntime {
    private let source = TemplateSource()

    func request(_ operation: String, data: Data) async throws -> Data {
        let decoder = JSONDecoder(), encoder = JSONEncoder()
        switch operation {
        case "collection":
            let link = try decoder.decode(String.self, from: data)
            let result = try await source.collection(link: link)
            try PluginContract.validate(result)
            return try encoder.encode(result)
        case "playback":
            let request = try decoder.decode(PluginPlaybackRequest.self, from: data)
            let result = try await source.playback(episode: request.episode)
            try PluginContract.validate(result)
            return try encoder.encode(result)
        default:
            throw PluginError(code: "UNSUPPORTED_OPERATION", message: "插件不支持该操作。", retryable: false)
        }
    }
}

@_cdecl("videohub_plugin_create_v1")
public func pluginCreate() -> UnsafeMutableRawPointer? {
    let address = MainActor.assumeIsolated { UInt(bitPattern: Unmanaged.passRetained(PluginRuntime()).toOpaque()) }
    return UnsafeMutableRawPointer(bitPattern: address)
}

@_cdecl("videohub_plugin_can_handle_v1")
public func pluginCanHandle(_ instance: UnsafeMutableRawPointer?, _ link: UnsafePointer<CChar>?) -> Int32 {
    guard instance != nil, let link else { return 0 }
    return TemplateSource.recognizes(String(cString: link)) ? 1 : 0
}

@_cdecl("videohub_plugin_data_store_v1")
public func pluginDataStore(_ instance: UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer? {
    nil
}

@_cdecl("videohub_plugin_request_v1")
public func pluginRequest(_ instance: UnsafeMutableRawPointer?, _ operation: UnsafePointer<CChar>?, _ payload: UnsafePointer<CChar>?, _ context: UnsafeMutableRawPointer?, _ reply: PluginReply) {
    guard let instance, let operation, let payload else {
        let error = "{\"code\":\"INVALID_REQUEST\",\"message\":\"请求参数无效。\",\"retryable\":false}"
        error.withCString { reply(context, nil, $0) }
        return
    }
    let operationCopy = String(cString: operation)
    let data = Data(String(cString: payload).utf8)
    let instanceAddress = UInt(bitPattern: instance)
    let contextAddress = context.map { UInt(bitPattern: $0) }
    let replyBox = ReplyBox(callback: reply)
    Task { @MainActor in
        let callback = replyBox.callback
        let runtime = Unmanaged<PluginRuntime>.fromOpaque(UnsafeMutableRawPointer(bitPattern: instanceAddress)!).takeUnretainedValue()
        let contextCopy = contextAddress.flatMap { UnsafeMutableRawPointer(bitPattern: $0) }
        do {
            let result = try await runtime.request(operationCopy, data: data)
            String(decoding: result, as: UTF8.self).withCString { callback(contextCopy, $0, nil) }
        } catch {
            let pluginError = error as? PluginError
            let failure = PluginFailureDTO(
                code: pluginError?.code ?? "PLUGIN_ERROR",
                message: error.localizedDescription,
                retryable: pluginError?.retryable ?? false
            )
            let data = (try? JSONEncoder().encode(failure)) ?? Data("{}".utf8)
            String(decoding: data, as: UTF8.self).withCString { callback(contextCopy, nil, $0) }
        }
    }
}
