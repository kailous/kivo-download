import VideoHubPluginSDK
import Foundation

struct TemplateSource {
    private struct Failure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    static func recognizes(_ link: String) -> Bool {
        guard let url = URL(string: link), ["http", "https"].contains(url.scheme ?? "") else { return false }
        return url.host == "example.invalid" && url.path.hasPrefix("/hello")
    }

    func collection(link: String) async throws -> PluginCollectionDTO {
        guard Self.recognizes(link), let url = URL(string: link) else {
            throw Failure(message: "链接不属于此插件。")
        }
        return PluginCollectionDTO(
            id: "hello",
            title: "示例作品",
            summary: "SDK 模板只描述接口形状，example.invalid 不会联网。",
            sections: [
                PluginSectionDTO(
                    id: "main",
                    title: "正片",
                    episodes: [
                        PluginEpisodeDTO(
                            id: "episode-1",
                            title: "第 1 集",
                            number: "1",
                            duration: 120,
                            canonicalURL: url,
                            role: .main,
                            availability: .released
                        )
                    ],
                    role: .main
                )
            ],
            isComplete: true
        )
    }

    func playback(episode: PluginEpisodeDTO) async throws -> PluginPlaybackDTO {
        throw Failure(message: "请在 TemplateSource.playback 中返回平台授权的媒体地址。")
    }
}
