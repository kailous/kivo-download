import Foundation

public typealias PluginReply = @convention(c) (UnsafeMutableRawPointer?, UnsafePointer<CChar>?, UnsafePointer<CChar>?) -> Void
public typealias PluginCreate = @convention(c) () -> UnsafeMutableRawPointer?
public typealias PluginCanHandle = @convention(c) (UnsafeMutableRawPointer?, UnsafePointer<CChar>?) -> Int32
public typealias PluginDataStore = @convention(c) (UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer?
public typealias PluginRequest = @convention(c) (UnsafeMutableRawPointer?, UnsafePointer<CChar>?, UnsafePointer<CChar>?, UnsafeMutableRawPointer?, PluginReply) -> Void

/// The `contentRating` field in a plugin package manifest.
public enum PluginContentRating: String, Codable, Sendable {
    case general, adult
}

/// Platform-independent editorial role; access rights (e.g. VIP) are separate.
public enum PluginContentRole: String, Codable, Sendable {
    case main, trailer, extra, alternate, unknown
    public init(from decoder: any Decoder) throws {
        self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
    }
}
public enum PluginEpisodeAvailability: String, Codable, Sendable {
    case released, unreleased, unavailable, unknown
    public init(from decoder: any Decoder) throws {
        self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
    }
}

public struct PluginEpisodeDTO: Codable, Sendable {
    public let id, title, number, subtitle, badge: String
    public let duration: Double
    public let cover, canonicalURL: URL?
    public let sourceData: [String: String]
    public let role: PluginContentRole?
    public let availability: PluginEpisodeAvailability?
    /// Marks continuously broadcast content; the host skips resume progress and uses Up/Down to switch adjacent live entries.
    public let isLive: Bool?
    public init(id: String, title: String, number: String = "", subtitle: String = "", badge: String = "", duration: Double = 0, cover: URL? = nil, canonicalURL: URL? = nil, sourceData: [String: String] = [:], role: PluginContentRole? = nil, availability: PluginEpisodeAvailability? = nil, isLive: Bool? = nil) {
        self.id = id; self.title = title; self.number = number; self.subtitle = subtitle; self.badge = badge
        self.duration = duration; self.cover = cover; self.canonicalURL = canonicalURL; self.sourceData = sourceData; self.role = role; self.availability = availability; self.isLive = isLive
    }
}
public struct PluginSectionDTO: Codable, Sendable {
    public let id, title: String
    public let episodes: [PluginEpisodeDTO]
    public let role: PluginContentRole?
    /// Explicitly shared only by sections the platform identifies as one playback sequence.
    public let playbackGroupID: String?
    public init(id: String, title: String, episodes: [PluginEpisodeDTO], role: PluginContentRole? = nil, playbackGroupID: String? = nil) {
        self.id = id; self.title = title; self.episodes = episodes; self.role = role; self.playbackGroupID = playbackGroupID
    }
}
public enum PluginContentType: String, Codable, Sendable, CaseIterable {
    case movie, series, animation, variety, documentary, unknown
    public init(from decoder: any Decoder) throws {
        self = Self(rawValue: try decoder.singleValueContainer().decode(String.self)) ?? .unknown
    }
}

public struct PluginCollectionDTO: Codable, Sendable {
    public let id, title, summary: String
    public let cover, backdrop: URL?
    public let sections: [PluginSectionDTO]
    public let isComplete: Bool?
    public let contentType: PluginContentType?
    public init(id: String, title: String, summary: String = "", cover: URL? = nil, backdrop: URL? = nil, sections: [PluginSectionDTO], isComplete: Bool? = nil, contentType: PluginContentType? = nil) {
        self.id = id; self.title = title; self.summary = summary; self.cover = cover; self.backdrop = backdrop; self.sections = sections; self.isComplete = isComplete; self.contentType = contentType
    }
}
public struct PluginPlaybackRequest: Codable, Sendable {
    public let episode: PluginEpisodeDTO
    public let quality: Int
    public init(episode: PluginEpisodeDTO, quality: Int) { self.episode = episode; self.quality = quality }
}
public struct PluginDanmakuRequest: Codable, Sendable {
    public let episode: PluginEpisodeDTO
    public let segment: Int
    public init(episode: PluginEpisodeDTO, segment: Int) { self.episode = episode; self.segment = segment }
}
public struct PluginQualityDTO: Codable, Sendable {
    public let id: Int
    public let label: String
    public init(id: Int, label: String) { self.id = id; self.label = label }
}
public struct PluginCatalogFilterDTO: Codable, Sendable, Identifiable {
    public let id, title: String
    public init(id: String, title: String) { self.id = id; self.title = title }
}
public struct PluginAdBreakDTO: Codable, Sendable {
    public let id: String
    public let start, end: Double
    public let canSkip: Bool
    public init(id: String, start: Double, end: Double, canSkip: Bool = false) { self.id = id; self.start = start; self.end = end; self.canSkip = canSkip }
}
public struct PluginAdPolicyDTO: Codable, Sendable {
    public let mode: String
    public let canSkip: Bool
    public let breaks: [PluginAdBreakDTO]
    public init(mode: String = "unknown", canSkip: Bool = false, breaks: [PluginAdBreakDTO] = []) { self.mode = mode; self.canSkip = canSkip; self.breaks = breaks }
}
public struct PluginPlaybackDTO: Codable, Sendable {
    public let video: URL
    public let audio: URL?
    public let preview: Bool
    public let format: String
    public let duration: Double
    public let qualities: [PluginQualityDTO]
    public let qualityID: Int
    public let headers: [String: String]
    public let expiresAt: Double?
    public let adPolicy: PluginAdPolicyDTO?
    public let inlineHLS: String?
    public init(video: URL, audio: URL? = nil, preview: Bool = false, format: String, duration: Double, qualities: [PluginQualityDTO], qualityID: Int, headers: [String: String] = [:], expiresAt: Double? = nil, adPolicy: PluginAdPolicyDTO? = nil, inlineHLS: String? = nil) {
        self.video = video; self.audio = audio; self.preview = preview; self.format = format; self.duration = duration
        self.qualities = qualities; self.qualityID = qualityID; self.headers = headers; self.expiresAt = expiresAt; self.adPolicy = adPolicy; self.inlineHLS = inlineHLS
    }
}
public struct PluginAccountDTO: Codable, Sendable {
    public let authenticated: Bool
    public let displayName: String?
    public init(authenticated: Bool, displayName: String? = nil) { self.authenticated = authenticated; self.displayName = displayName }
}
public struct PluginFailureDTO: Codable, Sendable {
    public let code, message: String
    public let retryable: Bool
    public init(code: String, message: String, retryable: Bool = false) { self.code = code; self.message = message; self.retryable = retryable }
}
public enum PluginDanmakuMode: String, Codable, Sendable { case scrolling, top, bottom }
public struct PluginDanmakuDTO: Codable, Sendable {
    public let id: String
    public let time: Double
    public let text: String
    public let mode: PluginDanmakuMode
    public let color: UInt32
    public let size: Double
    public init(id: String, time: Double, text: String, mode: PluginDanmakuMode, color: UInt32, size: Double) {
        self.id = id; self.time = time; self.text = text; self.mode = mode; self.color = color; self.size = size
    }
}

public enum PluginContractError: LocalizedError {
    case invalid(String)
    public var errorDescription: String? { switch self { case .invalid(let message): return message } }
}
public enum PluginContract {
    public static let apiVersion = 1
    public static let inlineHLSAPIVersion = 2
    public static func validate(_ collection: PluginCollectionDTO) throws {
        guard !collection.id.isEmpty, !collection.title.isEmpty, !collection.sections.isEmpty else { throw PluginContractError.invalid("作品标识、标题或目录为空。") }
        var sectionIDs = Set<String>()
        for section in collection.sections {
            guard !section.id.isEmpty, sectionIDs.insert(section.id).inserted else { throw PluginContractError.invalid("分区标识为空或重复。") }
            var episodeIDs = Set<String>()
            for episode in section.episodes {
                guard !episode.id.isEmpty, !episode.title.isEmpty, episode.duration.isFinite, episode.duration >= 0,
                      episodeIDs.insert(episode.id).inserted else { throw PluginContractError.invalid("剧集字段无效或同分区标识重复。") }
            }
        }
    }
    public static func validate(_ playback: PluginPlaybackDTO) throws {
        let urls = [playback.video, playback.audio].compactMap { $0 }
        guard urls.allSatisfy({ ["https", "http"].contains($0.scheme ?? "") && $0.host != nil }),
              ["DASH", "HLS", "HTTP"].contains(playback.format),
              playback.duration.isFinite, playback.duration >= 0,
              !playback.qualities.isEmpty, Set(playback.qualities.map(\.id)).count == playback.qualities.count,
              playback.qualities.contains(where: { $0.id == playback.qualityID }),
              playback.headers.count <= 32 else { throw PluginContractError.invalid("播放资源不符合插件接口规范。") }
        if playback.format == "DASH", playback.audio == nil, playback.video.pathExtension.lowercased() != "mpd" { throw PluginContractError.invalid("DASH 输出必须提供独立音频地址。") }
        if let playlist = playback.inlineHLS {
            guard playback.format == "HLS", playlist.utf8.count <= 2 * 1024 * 1024, playlist.hasPrefix("#EXTM3U"),
                  !playlist.unicodeScalars.contains(where: { $0.value == 0 }) else { throw PluginContractError.invalid("内联 HLS 播放列表无效。") }
            for line in playlist.components(separatedBy: .newlines).map({ $0.trimmingCharacters(in: .whitespaces) }) where !line.isEmpty && !line.hasPrefix("#") {
                guard let url = URL(string: line), ["http", "https"].contains(url.scheme ?? ""), url.host != nil else { throw PluginContractError.invalid("内联 HLS 的媒体 URI 必须是完整 HTTP 地址。") }
            }
            let pattern = "URI=\"([^\"]+)\""
            let expression = try NSRegularExpression(pattern: pattern)
            let full = NSRange(playlist.startIndex..<playlist.endIndex, in: playlist)
            for match in expression.matches(in: playlist, range: full) {
                guard let range = Range(match.range(at: 1), in: playlist), let url = URL(string: String(playlist[range])), ["http", "https"].contains(url.scheme ?? ""), url.host != nil else { throw PluginContractError.invalid("内联 HLS 资源 URI 无效。") }
            }
        }
        for (name, value) in playback.headers {
            guard !name.isEmpty, name.unicodeScalars.allSatisfy({ (65...90).contains($0.value) || (97...122).contains($0.value) || (48...57).contains($0.value) || $0.value == 45 }),
                  !value.unicodeScalars.contains(where: { $0.value == 10 || $0.value == 13 || $0.value == 0 }), value.utf8.count <= 8192 else { throw PluginContractError.invalid("媒体请求头无效。") }
        }
        if let expires = playback.expiresAt, !expires.isFinite || expires <= Date().timeIntervalSince1970 {
            throw PluginContractError.invalid("插件返回的媒体地址已经过期。")
        }
    }
    /// Advertising is an optional extension: unsupported metadata never suppresses
    /// an otherwise valid, platform-authorized media resource.
    public static func normalizedAdPolicy(_ policy: PluginAdPolicyDTO?) -> PluginAdPolicyDTO? {
        guard let policy, ["unknown", "none", "embedded", "clientSide"].contains(policy.mode) else { return nil }
        var end = 0.0, ids = Set<String>()
        for ad in policy.breaks {
            guard policy.mode == "embedded", !ad.id.isEmpty, ids.insert(ad.id).inserted, ad.start.isFinite, ad.end.isFinite, ad.start >= end, ad.end > ad.start else { return nil }
            end = ad.end
        }
        return policy
    }

}
