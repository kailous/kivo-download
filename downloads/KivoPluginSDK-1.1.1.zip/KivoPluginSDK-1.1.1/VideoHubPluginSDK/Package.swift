// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "VideoHubPluginSDK",
    platforms: [.macOS(.v14)],
    products: [
        .library(name: "VideoHubPluginSDK", targets: ["VideoHubPluginSDK"])
    ],
    targets: [
        .target(name: "VideoHubPluginSDK")
    ]
)
